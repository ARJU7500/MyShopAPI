﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using MyShopApi.Models;

namespace MyShopApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InventoryController : ControllerBase
    {
        [HttpPost]
        public ActionResult SaveInventryData(Inventory inventoryDto)
        {
            SqlConnection connection = new SqlConnection
            {
                ConnectionString= "Server=ARJUNEGI;Database=MYSHOP;Trusted_Connection=True;"
            };
            SqlCommand command = new SqlCommand
            {
                CommandText= "SP_INSERT_INVENTORY_DATA",
                CommandType= CommandType.StoredProcedure,
                Connection= connection
            };
            command.Parameters.AddWithValue("@p_PRODUCT_CODE", inventoryDto.ProductCode);
            command.Parameters.AddWithValue("@p_PRODUCT_NAME", inventoryDto.ProductName);
            command.Parameters.AddWithValue("@p_STOCK_AVAIBLE", inventoryDto.StockAvaible);
            command.Parameters.AddWithValue("@p_REORDER_STOCK", inventoryDto.ReOrderStock);
            command.Parameters.AddWithValue("@p_CREATED_BY", inventoryDto.CreatedBy);
            command.Parameters.AddWithValue("@p_CREATED_ON", inventoryDto.CreatedOn);
            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();
            return Ok("Inventry data saved");
        }
    }
}
